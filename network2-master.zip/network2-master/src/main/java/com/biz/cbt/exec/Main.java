package com.biz.cbt.exec;

import com.biz.cbt.service.CbtService;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		CbtService cs = new CbtService();
		
		cs.cbtMenu();
	}

}
